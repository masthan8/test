


module.exports={
    addDetails: async function(req){
        let productName=req.productName
        let productImages=req.productImages 
        let productDescription= req.productDescription  
        let discountName=req.discountName  
        let unitsInstocks=req.unitsInstocks  
        let productPrice=req.productPrice 
        let discount=req.discount 
        let couponCode= req.couponCode 
        let discountStartDate= req.discountStartDate 
        let discountEndDate=req.discountEndDate 
        let createdBy= req.createdBy
        let updatedBy= req.updatedBy
        let query='INSERT INTO marketing (product_name,product_images, product_description,discount_name,units_in_stock, product_price, discount, couponcode, discount_start_date, discount_end_date, created_by, updated_by) VALUES (?,?,?,?, ?,?, ?, ?, ?, ?, ?, ?)'
        try {  
            let rows=await dbcon.query(query,[productName,productImages,productDescription,discountName,unitsInstocks,productPrice,discount,couponCode,discountStartDate,discountEndDate,createdBy,updatedBy])
            console.log(rows);
            if(rows.affectedRows===1){
              return{"status":"successfully registered"}
            }
 
            }
            catch(err)
            {
                console.log(err);
                return {"status":"something went wrong"};
            }
    },
    updateDetails: async function(req){
        let productName=req.productName
        let productImages=req.productImages 
        let productDescription= req.productDescription  
        let discountName=req.discountName  
        let unitsInstocks=req.unitsInstocks  
        let productPrice=req.productPrice 
        let discount=req.discount 
        let couponCode= req.couponCode 
        let discountStartDate= req.discountStartDate 
        let discountEndDate=req.discountEndDate 
        let createdBy= req.createdBy
        let updatedBy= req.updatedBy
        let id=req.id
        let query='update marketing set product_name=?,product_images=?, product_description= ?,discount_name=?,units_in_stock=?, product_price=?, discount=?, couponcode=?, discount_start_date=?, discount_end_date=?, created_by=?, updated_by=? where id=?'
        try{
            let rows=await dbcon.query(query,[productName,productImages,productDescription,discountName,unitsInstocks,productPrice,discount,couponCode,discountStartDate,discountEndDate,createdBy,updatedBy,id])
            console.log(rows);
            if(rows.affectedRows===1){
              return{"status":"successfully registered"}
            }
            else{
                return{"status":"id is not found"}
            }
        }
        catch(err){
            console.log(err);
            return {"status":"something went wrong"};
        }
    },
    deleteDetails: async function(req){
        let id=req.id
        let query ='delete from marketing where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            console.log(rows);
            if(rows.affectedRows===1){
              return{"status":"successfully deleted"}
            }
            else{
                return{"status":"id is not found"}
            }
        }
        catch(err){
            console.log(err);
            return {"status":"something went wrong"};
        }
    
    },
    listById: async function(req){
        let id=req.id
        let query='select * from marketing where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            if (rows.length===0){
                return{"status":"id is not found "}
            }
            else{
                return rows
            }
        }
        catch(err){
            console.log(err);
            return {"status":"something went wrong"};
        }
    },
    allDetails: async function(req){
        let query='select * from marketing'
        try{
            let rows=await dbcon.query(query)
            if (rows.length===0){
                return{"status":"details is not found "}
            }
            else{
                return rows
            }
        }
        catch(err){
            console.log(err);
            return {"status":"something went wrong"};
        }
    }
}
