
module.exports={
    addEventCategory:async function(req){
        let category= req.category
        let createdBy= req.createdBy
        let updatedBy= req.updatedBy
        let query='INSERT INTO event_has_category (category,created_by,updated_by) VALUES (?,?,?)'
        try {
        let rows=await dbcon.query(query,[category,createdBy,updatedBy])
        console.log(rows);
        if(rows.affectedRows===1){
            return{"status":"successfully Event category registered"}
        }
        else{
            return{"status":"Not registered"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    updateEventCategory:async function(req){
        let category= req.category
        let createdBy= req.createdBy
        let updatedBy= req.updatedBy
        let id=req.id
        let query='update event_has_category  set category=?,created_by=?,updated_by=? where id=?';
        try{
        let rows=await dbcon.query(query,[category,createdBy,updatedBy,id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"this event is not exist"}
        }
        else{
            return{"status":"Event gategory is successfully updated"}
        }

        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    deleteEventCategory:async function(req){
         let id=req.id
         let query='delete from event_has_category where id=?'
         try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"the category id is not exist"}
        }
        else{
            return{"status":"successfully deleted"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    eventCategoryId:async function(req){
        let id=req.id
        let query='select * from event_has_category where id=?'
        try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.length===1){
            return rows
        }
         else{
            return{"status":"the user id is not exist"}
         }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    }
}