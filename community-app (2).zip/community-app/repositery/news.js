module.exports={
    addNews: async function(req){

       let categoryId= req.categoryId
       let title= req.title
       let image= req.image
       let content= req.content
       let createDate= req.createDate
       let updateDate= req.updateDate 
       let createdBy=req.createdBy
       let updatedBy=req.updatedBy

        let query='INSERT INTO news (category_id, title, image, content, created_date, updated_date, created_by, updated_by) VALUES (?, ?, ?, ?, ?, ?,?, ?)'
        try {
            let rows=await dbcon.query(query,[categoryId,title,image,content,createDate,updateDate,createdBy,updatedBy])
            console.log(rows);
            if(rows.affectedRows===1){
              return{"status":"successfully News inserted"}
            }
            else{
                return{"status":"Not inserted"}
            }
            }
            catch(err)
            {
                console.log(err);
                return {"status":"something went wrong"};
            }
    },
    updateNews: async function(req){
       
        let categoryId= req.categoryId
       let title= req.title
       let image= req.image
       let content= req.content
       let createDate= req.createDate
       let updateDate= req.updateDate 
       let createdBy=req.createdBy
       let updatedBy=req.updatedBy
       let id=req.id
        let query='update news set category_id=?, title=?, image=?, content=?, created_date=?, updated_date=?, created_by=?, updated_by=? where id=?'
        try{
            let rows=await dbcon.query(query,[categoryId,title,image,content,createDate,updateDate,createdBy,updatedBy,id])
            console.log(rows);
            if (rows.affectedRows===1){
                return{"status":"successfully updated"}
            }
            else{
                return{"status":"not updated"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    deleteNews: async function(req){
        let id=req.id
        let query='delete from  news  where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            console.log(rows);
            if (rows.affectedRows===1){
                return{"status":"successfully deleted"}
            }
            else{
                return{"status":"not deleted"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    listAllNews: async function(req){
        let id=req.id
        let query='select * from news where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            console.log(rows);
            if (rows.affectedRows===0){
                return{"status":"not found"}
            }
            else{
               return rows
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    }
    }
