module.exports={
    token: async function(token,userId){
        let query='update users set token="'+token+'" where id='+userId;
        let rows=dbcon.query(query)
        console.log('token successfully');
    }
}