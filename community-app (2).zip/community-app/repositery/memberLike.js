

module.exports={
    addLikes: async function(req){
        let newsId=req.newsId
        let memberId=req.memberId
        let status=req.status
        let query='INSERT INTO members_liked_news (news_id, member_id,status) VALUES (?,?,?)'
        try{
            let rows= await dbcon.query(query,[newsId,memberId,status])
            if (rows.affectedRows===0){
                return{"status":"Not Liked"}
            }
            else{
                return{"status":"Liked"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    deleteLikes: async function(req){
        let id=req.id
        let query='delete from members_liked_news where id=?'
        try{
            let rows= await dbcon.query(query,[id])
            if (rows.affectedRows===0){
                return{"status":"Not Liked"}
            }
            else{
                return{"status":"disliked"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
}
}