const moment=require('moment')
const bcryptjs=require('bcryptjs')

module.exports={

    addMember: async function(req){
        let name = req.name
        let phone = req.phone
        let email = req.email
        //let password = req.password
        let membersImage=req.membersImage
        let address=req.address
        let street=req.street
        let city=req.city
        let pincode=req.pincode
        let district=req.district
        let registerAt=moment().format('YYYY-MM-DD HH:mm:ss')
        let password=await bcryptjs.hashSync(req.password)
        let loggedIn='select * from members where email="'+email+'"';
        let query='INSERT INTO members (name, phone, email, password, members_image, address,token, street, city, pincode, district, register_at) values ("'+name+'","'+phone+'","'+email+'","'+password+'","'+membersImage+'","'+address+'",NULL,"'+street+'","'+city+'","'+pincode+'","'+district+'","'+registerAt+'")'
        try {
            let check=await dbcon.query(loggedIn);
            console.log(check);
            if(check.length===1){
              return {"status":"the user is already logged in"}
            }
            let rows=await dbcon.query(query)
            console.log(rows);
            if(rows.affectedRows===1){
              return{"status":"successfully registered"}
            }
 
            }
            catch(err)
            {
                console.log(err);
                return err;
            }
    },
    updateMember: async function(req){
        let password=bcryptjs.hashSync(req.password)
        let query='UPDATE  members set name="'+req.name+'", phone="'+req.phone+'", email="'+req.email+'", password="'+password+'", members_image="'+req.membersImage+'", address="'+req.address+'", street="'+req.street+'", city="'+req.city+'", pincode="'+req.pincode+'", district="'+req.district+'" where id='+req.id;
         console.log(query);
        try {
            console.log(query);
            let rows = await dbcon.query(query)
            if(rows.affectedRows===0){
                return{"status":"the user is not exist"}
            }
            else{
                return {
                    "status": "success"
                }
            }
        }
        catch (err) {
            console.log(err);
            return {"status":"something went wrong"}
        }
    },
    deleteMember: async function (req) {     
        let deletequery='delete from members where id ='+req.id;
        try {   
            let rows=await dbcon.query(deletequery)
            if(rows.affectedRows===0){
                return{
                    "status":"the user is not exist"
                }
            }
            else{
                return {
                    "status": "success"
                }
            }                     
            }
        catch (err) {
            console.log(err);
            return {"status":"something went wrong"}
        }
    },
    memberId: async function (req, res) {
        let query = 'select * from members where id='+req.id;
        try {
            console.log(query)
            let rows = await dbcon.query(query);
            if(rows.length===0){
                return{"status":"the user Id is not found"}
            }
            console.log(rows);           
            return rows
        } catch (error) {
            console.log(error);
            return {"status":"something went wrong"} ;
        }
    }
    
}