
module.exports={
    addMemberEventStatus:async function(req){
        let eventId=req.eventId
        let memberId=req.memberId
        let status=req.status
        let query='INSERT INTO event_has_members_activity (event_id,member_id,status) values (?,?,?)'
        try {
        let rows=await dbcon.query(query,[eventId,memberId,status])
        console.log(rows);
        if(rows.affectedRows===1){
            return{"status":"successfully Event status registered"}
        }
        else{
            return{"status":"event status Not registered"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    updateMemberEventStatus:async function(req){
        let eventId=req.eventId
        let memberId=req.memberId
        let status=req.status
        let id=req.id
        let query='update event_has_members_activity  set event_id=? ,member_id=? ,status=? where id=?'
        try{
        let rows=await dbcon.query(query,[eventId,memberId,status,id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"this event status is not exist"}
        }
        else{
            return{"status":"successfully member status updated"}
        }

        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    deleteMemberEventStatus:async function(req){
        let id=req.id
         let query='delete from event_has_members_activity where id=?'
         try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"the user id is not exist"}
        }
        else{
            return{"status":"successfully deleted"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    MemberEventStatusId:async function(req){
        let id=req.id
        let query='select * from event_has_members_activity where id=?'
        try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.length===1){
            return rows
        }
         else{
            return{"status":"the user id is not exist"}
         }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    }
}