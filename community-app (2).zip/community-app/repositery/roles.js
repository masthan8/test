const moment=require('moment')

module.exports={
    addRole:async function(req){
        let createDate=moment().format('YYYY-MM-DD HH:mm:ss')
    
        let query='INSERT INTO roles (name,create_date,update_date) VALUES (?,?,?)'
        let checkQuery='select* from roles where name=?'
        try{
            let check =await dbcon.query(checkQuery,[req.name])
            console.log(check);
            if(check.length===1){
                return{"status":"the role is already added"}
            }
            let rows=await dbcon.query(query,[req.name,createDate,createDate])
            console.log(rows);
            console.log(rows.insertId);
            if (rows.affectedRows===0){
                return{"status":"not inserted"}
            }
            else{
                return{
                    "status":"role successfully inserted",
                    "insertId":rows.insertId    
                }
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    updateRole:async function(req){
        let createDate=moment().format('YYYY-MM-DD HH:mm:ss')
        let query='update roles set name=?,update_date=?  where id=?'
        try{
            let rows=await dbcon.query(query,[req.name,createDate,req.id])
            console.log(rows);
            console.log(req.id);
            console.log(rows.insertId);
            if (rows.affectedRows===0){
                return{"status":"not updated"}
            }
            else{
                return{"status":"role successfully updated","insertId":req.id,
            }
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    deleteRole:async function(req){
        let query='delete from roles where id=?'
        try{
            let rows=await dbcon.query(query,[req.id])
            if (rows.affectedRows===0){
                return{"status":"not deleted"}
            }
            else{
                return{"status":"role successfully deleted","insertId":req.id}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    roleById:async function(req){
        let query='select * from roles where id=?'
        try{
            let rows=await dbcon.query(query,[req.id])
            if (rows.length===0){
                return{"status":"not inserted"}
            }
            else{
                return rows;
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    rolesList:async function(req){
        let query='select * from roles '
        try{
            let rows=await dbcon.query(query)
            if (rows.length===0){
                return{"status":"not inserted"}
            }
            else{
                return rows;
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },

}