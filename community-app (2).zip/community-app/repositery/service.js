

module.exports={
    addService:async function(req){
        let categoryId=req.categoryId;
        let serviceName=req.serviceName;
        let image=req.image;
        let description=req.description;
        let name=req.name;
        let address=req.address;
        let contactNo= req.contactNo;
        let createdBy=req.createdBy;
        let updatedBy=req.updatedBy

        let query='INSERT INTO services (category_id,service_name,image,service_description, name, address, contact_no, created_by,updated_by) VALUES (?,? ,? ,?, ?, ?, ?, ?, ?)'
        try{
            let rows=await dbcon.query(query,[categoryId,serviceName,image,description,name,address,contactNo,createdBy,updatedBy])
            if (rows.affectedRows===0){
                return{"status":"not inserted"}
            }
            else{
                return{"status":"service successfully inserted"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    updateService:async function(req){
        let categoryId=req.categoryId;
        let serviceName=req.serviceName;
        let image=req.image;
        let description=req.description;
        let name=req.name;
        let address=req.address;
        let contactNo= req.contactNo;
        let createdBy=req.createdBy;
        let updatedBy=req.updatedBy
        let id=req.id;
        let query='update services set category_id=? ,service_name=? ,image=? ,service_description=?, name= ?, address= ?, contact_no=?, created_by=?,updated_by=? where id=?'
        try{
            let rows=await dbcon.query(query,[categoryId,serviceName,image,description,name,address,contactNo,createdBy,updatedBy,id])
            if (rows.affectedRows===0){
                return{"status":"not inserted"}
            }
            else{
                return{"status":"service successfully updated"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    deleteService:async function(req){
        let id=req.id
        let query='delete from services where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            if (rows.affectedRows===0){
                return{"status":"not inserted"}
            }
            else{
                return{"status":"service successfully deleted"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    allServices:async function(req){
        let id=req.id
        let query='select * from services where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            if (rows.length===0){
                return{"status":"not inserted"}
            }
            else{
                return rows;
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    }
}