const bcryptjs = require('bcryptjs')
const jwt = require('jsonwebtoken')

module.exports = {
 /*  login and generating access token return to the user  */
  login: async function (req) {
    let email = req.email
    let password = req.password

    let query = 'select * from users where  email= ?'; // ? -> this is define 'ersath@gmail.com;drop table user'

    console.log(query);
    // let queryUser='select * from users where email="'+email+'"'
    try {
      let rows = await dbcon.query(query,[email,password])
      console.log(rows);
      if (await bcryptjs.compareSync(password, rows[0].password)) {
        const accessToken = await generateAccessToken({
          email: email,
          password: req.password
        })
        return {
          "status": "its true",
          "token": accessToken,
          "userId": rows[0].id,
          "name": rows[0].name
        }
      }
    }
    catch (err) {
      console.log(err);
      return { "status": "something went wrong" }
    }
  },
  /*  log out get token from the body and compare req.token and row[0].token if match update null in the database */
  logout: async function (req, res) {
    let token= req.token
    let query = 'select * from users where token= ?'
    try {
        let rows = await dbcon.query(query,[token])
        console.log(rows);
        console.log(rows[0].token);
        if (rows[0].token == req.token) {
        let tokenUpdate = 'update users set token=NULL where id="' + rows[0].id + '"'
        let tokens = await dbcon.query(tokenUpdate)
        return { "status": "user successfully logged out" }
      }
    }
    catch (err) {
        console.log(err);
        return { "status": "something went wrong" }
    }
  }
}

/*  access token generator */
function generateAccessToken(user) {
         return jwt.sign(user, process.env.ACCESS_TOKEN)
}
