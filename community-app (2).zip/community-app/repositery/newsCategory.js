module.exports={
    addNewsCategory: async function(req){
        let categoryName=req.categoryName
        let createdBy=req.createdBy
        let updatedBy=req.updatedBy
        let query= 'INSERT INTO news_has_category (category, created_by, updated_by) VALUES (?,?,?)'
        try {
            let rows=await dbcon.query(query,[categoryName,createdBy,updatedBy])
            console.log(rows);
            if(rows.affectedRows===1){
              return{"status":"successfully registered"}
            }
            else{
                return{"status":"Not successfully registered"}
            }
            }
            catch(err)
            {
                console.log(err);
                return {"status":"something went wrong"};
            }
    },
    updateCategory: async function(req){
        let categoryName=req.categoryName
        let createdBy=req.createdBy
        let updatedBy=req.updatedBy
        let id=req.id
        let query='update news_has_category set category =?, created_by=?, updated_by=? where id=?'
        try{
            let rows=await dbcon.query(query,[categoryName,createdBy,updatedBy,id])
            console.log(rows);
            if (rows.affectedRows===1){
                return{"status":"successfully updated"}
            }
            else{
                return{"status":"not updated"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    deleteCategory: async function(req){
        let id=req.id
        let query='delete from  news_has_category  where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            console.log(rows);
            if (rows.affectedRows===1){
                return{"status":"successfully deleted"}
            }
            else{
                return{"status":"not deleted"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    allCategory: async function(req){
        let id=req.id
        let query='select * from news_has_category where id=? '
        try{
            let rows=await dbcon.query(query,[id])
            console.log(rows);
            if (rows.affectedRows===0){
                return{"status":"not found"}
            }
            else{
               return rows
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    }
    }
