const moment=require('moment')
const bcryptjs=require('bcryptjs')
module.exports={
    addUser:async function(req){
        let created_at=moment().format('YYYY-MM-DD HH:mm:ss')

        let type=req.type
        let name=req.name
        let mobile=req.mobile
        let address=req.address
        let images=req.images
        let roleId=req.roleId
        /* let token="NULL" */
        let email=req.email
        let checkIn='select * from users where email=?'
        let password=bcryptjs.hashSync(req.password)
        let query='insert into users (type, name, mobile, email, password, token, create_at, updated_at, address, images,role_id) values (?,?,?,?,?,NULL,?,?,?,?,?)'
        try {
            let check=await dbcon.query(checkIn,[email])
            console.log(check);
            if (check.length===1){
                return{"status": "the user is already logged in"}
            }
            let rows=await dbcon.query(query,[type,name,mobile,email,password,created_at,created_at,address,images,roleId])

        console.log(rows);
        if(rows.affectedRows===1)
          return{"status":"successfully registered"}
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    updateUser:async function(req){
      let type=req.type
      let name=req.name
      let mobile=req.mobile
      let address=req.address
      let images=req.images
      let roleId=req.roleId
      /* let token="NULL" */
      let id=req.id
      let email=req.email
      let password=bcryptjs.hashSync(req.password)
        let query='update  users set  type=? , name=?, mobile=?, email=?, password="'+password+'", address="'+req.address+'", images="'+req.images+'" ,role_id="'+req.roleId+'" where id="'+req.id+'"'
        try {
        let rows=await dbcon.query(query,[type,name,mobile,email,password,address,images,roleId,id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"this id is not exist"}
        }
        else{
            return{"status":"successfully "}
        }

        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    deleteUser:async function(req){
        let id=req.id
         let query='delete from users where id=?'
         try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"the user id is not exist"}
        }
        else{
            return{"status":"successfully deleted"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    userId:async function(req){
      let id=req.id
        let query='select * from users where id=?'
        try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.length===1){
            return rows
        }
         else{
            return{"status":"the user id is not exist"}
         }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    }
}