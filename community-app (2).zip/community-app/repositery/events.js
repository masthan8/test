
module.exports={
    addEvent:async function(req){
        let categoryId =req.categoryId
        let  name=req.name
        let image =req.image
        let description=req.description
        let venue=req.venue
        let phone=req.phone
        let startdate=req.startdate
        let endDate=req.endDate
        let price=req.price
        let bookingId=req.bookingId
        let createdBy=req.createdBy
        let updatedBy=req.updatedBy
        let status=req.status
      

        let query='INSERT INTO events (category_id,name,image,description,venue, phone, start_date, end_date, price, booking_id, created_by, updated_by, status) VALUES ( ?, ?, ? , ?, ?, ?,?,?, ?, ?,?, ?, ?);'
        try {
        let rows=await dbcon.query(query,[categoryId,name,image,description,venue,phone,startdate,endDate,price,bookingId,createdBy,updatedBy,status])
        console.log(rows);
        if(rows.affectedRows===1){
            return{"status":"successfully Event registered"}
        }
        else{
            return{"status":"Not registered"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    updateEvent:async function(req){

        let categoryId =req.categoryId
        let  name=req.name
        let image =req.image
        let description=req.description
        let venue=req.venue
        let phone=req.phone
        let startdate=req.startdate
        let endDate=req.endDate
        let price=req.price
        let bookingId=req.bookingId
        let createdBy=req.createdBy
        let updatedBy=req.updatedBy
        let status=req.status
        let id=req.id

        let query='update events  set category_id=?, name=?, image=?,description=?,venue=?, phone=?, start_date=?, end_date=?, price=?, booking_id=?, created_by=?, updated_by=?, status=? where id=?'
        try{
        let rows=await dbcon.query(query,[categoryId,name,image,description,venue,phone,startdate,endDate,price,bookingId,createdBy,updatedBy,status,id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"this event is not exist"}
        }
        else{
            return{"status":"successfully events updated"}
        }

        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    deleteEvent:async function(req){
        let id=req.id
         let query='delete from events where id=?'
         try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.affectedRows===0){
            return{"status":"the user id is not exist"}
        }
        else{
            return{"status":"successfully deleted"}
        }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    },
    eventId:async function(req){
        let id=req.id
        let query='select * from events where id=?'
        try {
        let rows=await dbcon.query(query,[id])
        console.log(rows);
        if(rows.length===1){
            return rows
        }
         else{
            return{"status":"the user id is not exist"}
         }
        }
        catch(err){
        console.log(err);
        return{"status":"something went wrong"}
      }
    }
}