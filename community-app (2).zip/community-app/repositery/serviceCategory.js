

module.exports={
    addServiceCategory:async function(req,res){
        let category=req.category
        let createdBy=req.createdBy
        let updatedBy=req.updatedBy
        let query='INSERT INTO  services_has_category (category,created_by,updated_by) VALUES (?,?,?)'
        try{
            let rows=await dbcon.query(query,[category,createdBy,updatedBy])
            if(rows.affectedRows===0){
                return{"status":"service is not inserted"}
            }
            else{
                return{"status":"service is added"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something"}  
        }
    },
    updateServiceCategory: async function(req,res){
        let category=req.category
        let createdBy=req.createdBy
        let updatedBy=req.updatedBy
        let id=req.id
        console.log(id);
       let query='update services_has_category set category=? ,created_by=? ,updated_by=? where id=?' 
        try{
            let rows= await dbcon.query(query,[category,createdBy,updatedBy,id])
            if (rows.affectedRows===0){
                return{"status":"it's not successfully updated"}
            }
            else{
                return{"status":"successfully updated"}
            }
        }
        catch(err){
            console.log(err);
            return{'status':"something went wrong"}
        }
    },
    deleteServiceCategory: async function(req){
        let id=req.id
        let query= 'delete from services_has_category where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            if (rows.affectedRows===0){
                return{"status":"this id is not found"}
            }
            else{
                return{"status":"successfully deleted"}
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    },
    allServiceCategory: async function(req){
        let id=req.id
        let query='select * from  services_has_category where id=?'
        try{
            let rows=await dbcon.query(query,[id])
            if (rows.length===0){
                return{"status":"this id is not found"}
            }
            else{
                return rows
            }
        }
        catch(err){
            console.log(err);
            return{"status":"something went wrong"}
        }
    }
}
