const memberServices=require('../services/memberServices')

module.exports={
    addMember: async function(req,res){
        var response= await memberServices.addMember(req.body)
        res.status(200).json(response);
    },
    updateMember: async function(req,res){
        var response= await memberServices.updateMember(req.body)
        res.status(200).json(response);
    },
    deleteMember: async function(req,res){
        var response= await memberServices.deleteMember(req.body)
        res.status(200).json(response);
    },
    memberId: async function(req,res){
        var response= await memberServices.memberId(req.body)
        res.status(200).json(response);
    }


}