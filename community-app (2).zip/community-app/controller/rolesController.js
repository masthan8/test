const rolesService=require('../services/rolesService')

module.exports={
    addRole:async function(req,res){
        var response=await rolesService.addRole(req.body)
        res.status(200).json(response)
    },
    updateRole:async function(req,res){
        var response=await rolesService.updateRole(req.body)
        res.status(200).json(response)
    },
    deleteRole:async function(req,res){
        var response=await rolesService.deleteRole(req.body)
        res.status(200).json(response)
    },
    roleById:async function(req,res){
        var response=await rolesService.roleById(req.body)
        res.status(200).json(response)
    },
    rolesList:async function(req,res){
        var response=await rolesService.rolesList(req.body)
        res.status(200).json(response)
    }
}