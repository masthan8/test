const userServices=require('../services/userService')

module.exports={
    addUser: async function(req,res){
        var response=await userServices.addUser(req.body);
        res.status(200).json(response)
    },
    updateUser: async function(req,res){
        var response=await userServices.updateUser(req.body);
        res.status(200).json(response)
    },
    deleteUser: async function(req,res){
        var response=await userServices.deleteUser(req.body);
        res.status(200).json(response)
    },
    userId: async function(req,res){
        var response=await userServices.userId(req.body);
        res.status(200).json(response)
    }
}