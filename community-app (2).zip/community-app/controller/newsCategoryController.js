
const newsCategoryServices=require('../services/newsCategoryService')

module.exports={
    addNewsCategory: async function(req,res){
        var response=await newsCategoryServices.addNewsCategory(req.body)
        res.status(200).json(response)
    },
    updateCategory: async function(req,res){
        var response=await newsCategoryServices.updateCategory(req.body)
        res.status(200).json(response)
    },
    deleteCategory: async function(req,res){
        var response=await newsCategoryServices.deleteCategory(req.body)
        res.status(200).json(response)
    },
    allCategory: async function(req,res){
        var response=await newsCategoryServices.allCategory(req.body)
        res.status(200).json(response)
    }
}
