const marketingServices = require('../services/marketingService');

module.exports = {    
    addDetails: async function (req, res){        
        var response = await marketingServices.addDetails(req.body);
        res.status(200).json(response);
    },
    updateDetails: async function (req, res){        
        var response = await marketingServices.updateDetails(req.body);
        res.status(200).json(response);
    },
    deleteDetails: async function (req, res){        
        var response = await marketingServices.deleteDetails(req.body);
        res.status(200).json(response);
    },
    listById: async function (req, res){        
        var response = await marketingServices.listById(req.body);
        res.status(200).json(response);
    },
    allDetails: async function (req, res){           
        var response = await marketingServices.allDetails(req.body);
        res.status(200).json(response);      
    }
}