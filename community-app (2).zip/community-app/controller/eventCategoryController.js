
const eventCategoryServices=require('../services/eventCategoryService')

module.exports={
    addEventCategory: async function(req,res){
        var response=await eventCategoryServices.addEventCategory(req.body);
        res.status(200).json(response)
    },
    updateEventCategory: async function(req,res){
        var response=await eventCategoryServices.updateEventCategory(req.body);
        res.status(200).json(response)
    },
    deleteEventCategory: async function(req,res){
        var response=await eventCategoryServices.deleteEventCategory(req.body);
        res.status(200).json(response)
    },
    eventCategoryId: async function(req,res){
        var response=await eventCategoryServices.eventCategoryId(req.body);
        res.status(200).json(response)
    }
}