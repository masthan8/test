
const serviceHasService=require('../services/serviceHasService')

module.exports={
    addService:async function(req,res){
        var response=await serviceHasService.addService(req.body)
        res.status(200).json(response)
    },
    updateService:async function(req,res){
        var response=await serviceHasService.updateService(req.body)
        res.status(200).json(response)
    },
    deleteService:async function(req,res){
        var response=await serviceHasService.deleteService(req.body)
        res.status(200).json(response)
    },
    allServices:async function(req,res){
        var response=await serviceHasService.allServices(req.body)
        res.status(200).json(response)
    }
}