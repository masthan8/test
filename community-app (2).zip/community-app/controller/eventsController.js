
const eventServices=require('../services/eventsServices')

module.exports={
    addEvent: async function(req,res){
        var response=await eventServices.addEvent(req.body);
        res.status(200).json(response)
    },
    updateEvent: async function(req,res){
        var response=await eventServices.updateEvent(req.body);
        res.status(200).json(response)
    },
    deleteEvent: async function(req,res){
        var response=await eventServices.deleteEvent(req.body);
        res.status(200).json(response)
    },
    eventId: async function(req,res){
        var response=await eventServices.eventId(req.body);
        res.status(200).json(response)
    }
    
}