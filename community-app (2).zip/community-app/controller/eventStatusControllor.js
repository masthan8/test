
const memberEventActivityServices=require('../services/eventStatusService')

module.exports={
    addMemberEventStatus: async function(req,res){
        var response=await memberEventActivityServices.addMemberEventStatus(req.body);
        res.status(200).json(response)
    },
    updateMemberEventStatus: async function(req,res){
        var response=await memberEventActivityServices.updateMemberEventStatus(req.body);
        res.status(200).json(response)
    },
    deleteMemberActivity: async function(req,res){
        var response=await memberEventActivityServices.deleteMemberActivity(req.body);
        res.status(200).json(response)
    },
    deleteMemberEventStatus: async function(req,res){
        var response=await memberEventActivityServices.deleteMemberEventStatus(req.body);
        res.status(200).json(response)
    },
    MemberEventStatusId: async function(req,res){
        var response=await memberEventActivityServices.MemberEventStatusId(req.body);
        res.status(200).json(response)
    }
    
}