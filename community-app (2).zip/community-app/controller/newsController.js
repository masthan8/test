const newsServices=require('../services/newsServices')

module.exports={
    addNews: async function(req,res){
        var response=await newsServices.addNews(req.body)
        res.status(200).json(response)
    },
    updateNews: async function(req,res){
        var response=await newsServices.updateNews(req.body)
        res.status(200).json(response)
    },
    deleteNews: async function(req,res){
        var response=await newsServices.deleteNews(req.body)
        res.status(200).json(response)
    },
    listAllNews: async function(req,res){
        var response=await newsServices.listAllNews(req.body)
        res.status(200).json(response)
    }
}



