


const serviceCategoryServices=require('../services/serviceCategoryServices')

module.exports={
    addServiceCategory: async function(req,res){
        var response=await serviceCategoryServices.addServiceCategory(req.body)
        res.status(200).json(response)
    },
    updateServiceCategory: async function(req,res){
        var response=await serviceCategoryServices.updateServiceCategory(req.body)
        res.status(200).json(response)
    },
    deleteServiceCategory: async function(req,res){
        var response=await serviceCategoryServices.deleteServiceCategory(req.body)
        res.status(200).json(response)
    },
    allServiceCategory: async function(req,res){
        var response=await serviceCategoryServices.allServiceCategory(req.body)
        res.status(200).json(response)
    }
}
