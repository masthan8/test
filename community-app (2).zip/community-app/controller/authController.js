
const authServices=require('../services/authServices')

module.exports={
    login: async function(req,res){
        var response= await authServices.login(req.body)
        res.status(200).json(response);
    },
    logout: async function(req,res){
        var response=await authServices.logout(req.body)
        res.status(200).json(response)
    }
}