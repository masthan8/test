const memberLikeServices=require('../services/memberLikeService')


module.exports={
    addLikes: async function(req,res){
        var response=await memberLikeServices.addLikes(req.body)
        res.status(200).json(response)

    },
    deleteLikes:async function(req,res){
        var response=await memberLikeServices.deleteLikes(req.body)
        res.status(200).json(response)
    }
}