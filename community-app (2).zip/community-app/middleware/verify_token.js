const jwt = require('jsonwebtoken')


function validateToken(req, res, next) {           /* this is a middlewar function in any router every second argument consider middlewar */
    try {
        // console.log(req);
        // console.log(req.headers);
        /* get jwt token from  req.headers */
        console.log(req.headers['authorization']);
        const authHeader = req.headers['authorization'];
        // console.log(authHeader);
        /* split bearer  */
        const token = authHeader.split(' ')[1];
        console.log(token);
        /* compare req.headers token and dotenv access token */
        const decode = jwt.verify(token, process.env.ACCESS_TOKEN);
        console.log(decode);
        req.userData = decode
        console.log(req.userData);
        next()
    }
    catch (err) {
        console.log(err);
        return res.send({ 'status': "something went wrong" })
    }
}
module.exports = validateToken


