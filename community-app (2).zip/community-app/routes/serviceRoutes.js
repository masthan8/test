const express=require('express')
const router=express.Router();
const serviceCategoryController=require('../controller/serviceCategoryController')
const serviceController=require('../controller/serviceController');
const validateToken = require('../middleware/verify_token');

router.use(function(req,res,next){
    console.log('Request method: ' + req.method);
    console.log('Request payload: ' + JSON.stringify(req.body));
    console.log('Request URL: ' + req.url);
    next();
})
//====================this routes for add service category==============//
router.post('/add/service/category',validateToken,serviceCategoryController.addServiceCategory);
router.post('/update/service/category',validateToken,serviceCategoryController.updateServiceCategory);
router.post('/delete/service/category',validateToken,serviceCategoryController.deleteServiceCategory);
router.get('/list/service/category',validateToken,serviceCategoryController.allServiceCategory);

//====================this routes for add news ======================//
router.post('/add/services',validateToken,serviceController.addService);
router.post('/update/services',validateToken,serviceController.updateService);
router.post('/delete/services',validateToken,serviceController.deleteService);
router.get('/list/services',validateToken,serviceController.allServices);

module.exports=router;   