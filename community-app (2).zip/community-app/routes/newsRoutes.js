const express=require('express')
const router=express.Router();
const newsCategoryController=require('../controller/newsCategoryController')
const newsController=require('../controller/newsController');
const validateToken = require('../middleware/verify_token');

router.use(function(req,res,next){
    console.log('Request method: ' + req.method);
    console.log('Request payload: ' + JSON.stringify(req.body));
    console.log('Request URL: ' + req.url);
    next();
})
//====================this routes for add news category==============//
router.post('/add/news/category',validateToken,newsCategoryController.addNewsCategory);
router.post('/update/news/category',validateToken,newsCategoryController.updateCategory);
router.post('/delete/news/category',validateToken,newsCategoryController.deleteCategory);
router.get('/list/news/category',validateToken,newsCategoryController.allCategory);

//====================this routes for add news ======================//
router.post('/add/news',validateToken,newsController.addNews);
router.post('/update/news',validateToken,newsController.updateNews);
router.post('/delete/news',validateToken,newsController.deleteNews);
router.get('/list/newses',validateToken,newsController.listAllNews);

module.exports=router;   