const express=require('express')
const router=express.Router();
const userController=require('../controller/userController')
const cors=require('cors')
const validateToken=require('../middleware/verify_token')
router.use(function(req,res,next){
    console.log('Request method :',req.method);
    console.log('Request payload :',JSON.stringify(req.body));
    console.log('Request URL :',req.url);
    next()
})

router.post('/add/user',userController.addUser);
router.post('/update/user',validateToken,userController.updateUser);
router.post('/delete/user',validateToken,userController.deleteUser);
router.post('/user/id',validateToken,userController.userId);


module.exports=router