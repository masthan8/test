const express=require('express')
const router=express.Router();
const authController=require('../controller/authController')
const cors=require('cors')

router.use(function(req,res,next){
    console.log('Request method :',req.method);
    console.log('Request payload :',JSON.stringify(req.body));
    console.log('Request URL :',req.url);
    next()
})

router.post('/login',authController.login);
router.post('/logout',authController.logout);



module.exports=router