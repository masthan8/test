const express=require('express')
const router=express.Router();
const eventsController=require('../controller/eventsController')
const eventCategoryController=require('../controller/eventCategoryController')
const eventStatusControllor=require('../controller/eventStatusControllor')

const cors=require('cors');
const validateToken = require('../middleware/verify_token');


router.use(function(req,res,next){
    console.log('Request method :',req.method);
    console.log('Request payload :',JSON.stringify(req.body));
    console.log('Request URL :',req.url);
    next()
})
// ==============>this Router: add event,update,delete <========= //
router.post('/add/event',validateToken,eventsController.addEvent);
router.post('/update/event',validateToken,eventsController.updateEvent);
router.post('/delete/event',validateToken,eventsController.deleteEvent);
router.post('/event/id',validateToken,eventsController.eventId);
// ==============>this Router: add event category,update,delete <========= //
router.post('/add/event/category',validateToken,eventCategoryController.addEventCategory);
router.post('/update/event/category',validateToken,eventCategoryController.updateEventCategory);
router.post('/delete/event/category',validateToken,eventCategoryController.deleteEventCategory);
router.post('/event/id/category',validateToken,eventCategoryController.eventCategoryId);
// ==============>this Router: add event member status,update,delete <========= //
router.post('/add/member/event/status',validateToken,eventStatusControllor.addMemberEventStatus);
router.post('/update/member/event/status',validateToken,eventStatusControllor.updateMemberEventStatus);
router.post('/delete/member/event/status',validateToken,eventStatusControllor.deleteMemberEventStatus);
router.post('/event/status/id',validateToken,eventStatusControllor.MemberEventStatusId);

module.exports=router