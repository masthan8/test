const express=require('express')
const router=express.Router();
const memberController=require('../controller/memberController')
const memberLikedNews=require('../controller/memberLikeController')
const cors=require('cors')
const validateToken=require('../middleware/verify_token')
router.use(function(req,res,next){
    console.log('Request method :',req.method);
    console.log('Request payload :',JSON.stringify(req.body));
    console.log('Request URL :',req.url);
    next()
})
//===================add memberes=================//
// router.post('/add/member',memberController.addMember);
// router.post('/update/member',memberController.updateMember);
// router.post('/delete/member',memberController.deleteMember);
// router.post('/member/id',memberController.memberId);

//====================members liked newses===========//
router.post('/add/likes',validateToken,memberLikedNews.addLikes);
router.post('/delete/likes',validateToken,memberLikedNews.deleteLikes);


module.exports=router