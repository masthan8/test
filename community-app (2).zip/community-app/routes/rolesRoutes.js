const express=require('express')
const router=express.Router();
const rolesController=require('../controller/rolesController');
const validateToken = require('../middleware/verify_token');
router.use(function(req,res,next){
    console.log('Request method: ' + req.method);
    console.log('Request payload: ' + JSON.stringify(req.body));
    console.log('Request URL: ' + req.url);
    next();
})

router.post('/add/role',validateToken,rolesController.addRole);
router.post('/update/role',validateToken,rolesController.updateRole);
router.post('/delete/role',validateToken,rolesController.deleteRole);
router.get('/role/get/by/id',validateToken,rolesController.roleById);
router.get('/roles/list',validateToken,rolesController.rolesList);

module.exports=router;   