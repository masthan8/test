const express=require('express')
const router=express.Router();
const marketingController=require('../controller/marketingController');
const validateToken = require('../middleware/verify_token');
router.use(function(req,res,next){
    console.log('Request method: ' + req.method);
    console.log('Request payload: ' + JSON.stringify(req.body));
    console.log('Request URL: ' + req.url);
    next();
})

router.post('/add/details',validateToken,marketingController.addDetails);
router.post('/update/product',validateToken,marketingController.updateDetails);
router.post('/delete/product',validateToken,marketingController.deleteDetails);
router.get('/list/by/id',validateToken,marketingController.listById);
router.get('/list/all',validateToken,marketingController.allDetails);

module.exports=router;   