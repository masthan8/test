const express=require('express')
const bodyparser=require('body-parser')
const app=express();
app.use(express.json())
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended:true}))

/* database connection used globally */
global.dbcon=require('./database/db')

/* require dotenv */
require('dotenv').config();

/* routers url */
var members=require('./routes/membersRoutes');
app.use('/',members);
var login=require('./routes/authRoutes');
app.use('/',login);
var users=require('./routes/userRoutes');
app.use('/',users);
var events=require('./routes/eventsRoutes')
app.use('/',events)
var marketing=require('./routes/marketingRoutes')
app.use('/',marketing)
var news=require('./routes/newsRoutes')
app.use('/',news)
var services=require('./routes/serviceRoutes')
app.use('/',services)
var roles=require('./routes/rolesRoutes');
app.use('/',roles)

/* sample token test */
const verifytoken=require('./middleware/verify_token')
app.post('/posts',verifytoken,function(req,res){
    console.log('successfully logged in');
   res.send("status successfully logged in")
})
/* listening port 3000 */
app.listen(3000,()=>{
    console.log('port 3000 is launched');
})