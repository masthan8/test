const mysql =require('mysql')
var util = require('util');

const con=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"community_project"   
})

con.connect(function(){
    console.log('connected to database')
})
 
con.query = util.promisify(con.query)
module.exports=con